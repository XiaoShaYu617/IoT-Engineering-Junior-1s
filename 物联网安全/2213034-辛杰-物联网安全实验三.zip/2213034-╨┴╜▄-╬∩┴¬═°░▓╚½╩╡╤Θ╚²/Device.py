import paho.mqtt.client as mqtt
import time
import random
from datetime import datetime
import hashlib
import uuid
# MQTT服务器地址和端口
MQTT_BROKER = '192.168.188.130'
MQTT_PORT = 1883
MQTT_TOPIC = 'home'

status = 'off'

def generate_device_id():
    return str(uuid.uuid1())  # 使用时间戳生成UUID

device_id = generate_device_id()
# 创建MQTT客户端实例
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

# 连接到MQTT服务器
client.connect(MQTT_BROKER, MQTT_PORT, 60)

# 连接回调
def on_connect(client, userdata, flags, reason_code, properties):
    global device_name
    if reason_code == 0:
        device_name = input("Please enter device name: ")
        print(f"device name: {device_name}")
    else:
        print("Failed to connect, return code %d\n", reason_code)

# 消息处理回调
import time

from datetime import datetime
import time

# 消息处理回调
def on_message(client, userdata, msg):
    global status
    parts = msg.payload.decode().split('|')
    # 检查消息是否包含四个部分，即动作、时间戳、随机数和哈希值
    if len(parts) == 4:
        action, timestamp, nonce, received_hash = parts
        current_time = int(time.time())
        # 验证时间戳是否在合理的时间范围内
        timestamp_int = int(datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S").timestamp())
        if timestamp_int > current_time - 60 and timestamp_int < current_time + 60:
            # 验证随机数是否有效
            if nonce.isdigit() and len(nonce) == 9:  # 因为random.randint生成的是9位数字
                # 计算接收到的消息（不包括哈希值）的哈希值
                message = f"{action}|{timestamp}|{nonce}"
                hash_object = hashlib.sha256(message.encode())
                hash_hex = hash_object.hexdigest()
                # 比较计算出的哈希值与接收到的哈希值
                if hash_hex == received_hash:
                    status = action
                    print(f"Status updated to: {status}")
                else:
                    print("Received a message with invalid hash.")
            else:
                print("Received a message with invalid nonce.")
        else:
            print("Received a message with incorrect timestamp.")
    else:
        print("Received a message with incorrect format.")

client.on_message = on_message
client.on_connect = on_connect

client.subscribe(MQTT_TOPIC + "/" + device_id)

print(f"device Id: {device_id}")
print(f"Status: {status}")

# 开始循环
client.loop_start()

# 保持运行
try:
    while True:
        pass
except KeyboardInterrupt:
    client.loop_stop()