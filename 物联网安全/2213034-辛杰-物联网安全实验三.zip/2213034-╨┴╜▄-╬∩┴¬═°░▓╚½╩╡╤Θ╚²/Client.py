import paho.mqtt.client as mqtt
from datetime import datetime
import random
import hashlib

# MQTT服务器地址和端口
MQTT_BROKER = '192.168.188.130'
MQTT_PORT = 1883
MQTT_TOPIC = 'home'

# 提示用户输入用户名
username = input("Please enter your username: ")

# 打印欢迎信息
print(f"Welcome, {username}!")

# 创建MQTT客户端实例
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

# 连接到MQTT服务器
client.connect(MQTT_BROKER, MQTT_PORT, 60)

# 订阅主题
client.subscribe(MQTT_TOPIC + "/#")  # 订阅home主题下的所有子主题

# 开始循环
client.loop_start()

# 发送控制命令
def control_device(device_id, action):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    nonce = str(random.randint(100000000, 999999999))  # 生成随机数（nonce）
    message = f"{action}|{timestamp}|{nonce}"  # 构造消息
    hash_object = hashlib.sha256(message.encode())  # 计算SHA-256哈希值
    hash_hex = hash_object.hexdigest()  # 将哈希值转换为十六进制字符串
    payload = f"{message}|{hash_hex}"  # 将哈希值附加到消息中
    client.publish(f"{MQTT_TOPIC}/{device_id}", payload)

# 用户控制设备
def user_control():
    global sequence_number
    while True:
        device_id = input("Enter device ID: ")
        action = input("Enter action (on/off): ")
        control_device(device_id, action)

# 调用用户控制设备函数
user_control()

# 停止循环
client.loop_stop()